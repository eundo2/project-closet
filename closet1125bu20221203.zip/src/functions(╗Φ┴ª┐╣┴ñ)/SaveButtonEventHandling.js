// import React, { useState } from 'react';
// import ClothInfo from './ClothInfo';
// import { ImageUpload } from './ImageUpload';

// const SaveButtonEventHandling = () => {
//   const [message, setMessage] = useState('');

//   return (
//     <div>
//       <h1>Event Practice</h1>
//       <input
//         type="text"
//         name="message"
//         placeholder="아무거나 입력하세요"
//         value={message}
//         onChange={(e) => {
//           setMessage(e.target.value);
//         }}
//       />
//       <button
//         onClick={() => {
//           alert(message);
//           setMessage('');
//         }}
//       >
//         확인
//       </button>
//     </div>
//   );
// };

// export default SaveButtonEventHandling;
