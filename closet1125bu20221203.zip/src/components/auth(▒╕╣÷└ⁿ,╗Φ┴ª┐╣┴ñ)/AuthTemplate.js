// import React from 'react';
// import styled from 'styled-components';
// import imgA from './imgA.jpg';
// import closet from './closet.png';
// import closet2 from './closet2.png';
// import wardrobe from './wardrobe.png';
// import Login from './Login';
// import LoginComponent from './Login';
// import Loginscreen from './LoginScreen';
// import Register from './Register';

// // 페이지 틀 아래부분
// const AuthTemplateBlock = styled.div`
//   position: absolute;
//   left: 0;
//   right: 0;
//   top: 110px;
//   bottom: 0;
//   display: flex;
//   flex-direction: cloumn;
//   justify-content: center;
//   aligh-items: center;
// `;
// // contents있는부분
// const WhiteBox = styled.div`
//   .logo-area {
//     display: block;
//     padding-bottom: 2rem;
//     text-align: center;
//     font-weight: bold;
//     letter-spacing: 2px;
//   }
//   box-shadow: 0 0 8px rgba(0, 0, 0, 0.025);
//   padding: 2rem;
//   width: 360px;
//   background: white;
//   border-radius: 2px;
// `;

// const AuthTemplate = ({ children }) => {
//   return (
//     <div>
//       {/* <div class="menu">
//         <a class="super_title"> 옷장예보 &gt; 로그인</a>
//       </div> */}
//       <AuthTemplateBlock>
//         <WhiteBox>
//           <div className="logo-area">
//             <img src={closet} width="70%" height="70%" />
//           </div>
//           {/* <Loginscreen /> */}
//           {/* <Login /> */}
//           {/* <Register /> */}
//           {children}
//         </WhiteBox>
//       </AuthTemplateBlock>
//     </div>
//   );
// };

// export default AuthTemplate;
