// import React from 'react';
// import styled from 'styled-components';
// import palette from '../../lib/styles/palette';
// import { css } from "styled-components";
// export default class MenuTab extends Component {
//     render() {
//         return(
//             <div className="wrapper">
//                 <ul className="tabs">
//                     <li>아우터</li>
//                     <li>상의</li>
//                     <li>하의</li>
//                     <li>한벌옷</li>
//                     <li>내코디</li>
//                 </ul>
//                 <div className="contents">
                    
//                 </div>
//             </div>
//         )
//     }
// }