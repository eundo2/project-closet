// import React from 'react';
// import { NavLink } from 'react-router-dom';
// import 'C:/Users/Owner/Desktop/pro_react/closet/src/styles/common/Nav.css';

// const Nav = () => {
//   return (
//     <nav>
//       <div>
//         <NavLink to="/">옷장예보</NavLink>
//       </div>
//       <div>
//         <NavLink to="/login">로그인</NavLink>
//       </div>
//       <div>
//         <NavLink to="/add">옷 등록</NavLink>
//       </div>
//       <div>
//         <NavLink to="/match">코디 등록</NavLink>
//       </div>
//     </nav>
//   );
// };

// export default Nav;
