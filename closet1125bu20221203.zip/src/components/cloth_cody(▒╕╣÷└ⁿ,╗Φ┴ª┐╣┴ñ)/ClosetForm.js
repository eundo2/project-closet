// import React from 'react';
// import styled from 'styled-components';

// const textMap = {
//   add: '옷등록',
//   match: '코디등록',
// };
// const ClosetFormBlock = styled.div`
//   position: absolute;
//   left: 10px;
//   // top: 100px;
//   // bottom: 10%;
//   // right: 75%;
//   justify-content: center;
//   aligh-items: center;
// `;
// const ClosetForm = ({ type }) => {
//   const text = textMap[type];
//   return <ClosetFormBlock />;
// };
// export default ClosetForm;
